package modele;

public class Soigneur extends Case{
	
	public void action (Aventurier a)
	{
		
		a.setVp(a.getVp()+20);
		a.setStep(a.getStep()+1);
	}

}
