package modele;

public class Porte extends Case {
	
	public void action (Aventurier a)
	{
		a.setStep(a.getStep()+1);
	}

}
