package modele;

public class Eau extends Case{
	public void action (Aventurier a)
	{
		a.setEau(a.getEau()+1);
		a.setVp(a.getVp()-5+a.getEau()*2);
		a.setStep(a.getStep()+1);
	}

}
