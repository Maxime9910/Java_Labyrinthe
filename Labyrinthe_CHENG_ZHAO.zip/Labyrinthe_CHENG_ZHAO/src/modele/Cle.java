package modele;

public class Cle extends Case{
	
	public void action (Aventurier a)
	{
		a.setCle(a.getCle()+1);
		a.setVp(a.getVp()-5+a.getEau()*2);
		a.setStep(a.getStep()+1);
		
	
	}
}

