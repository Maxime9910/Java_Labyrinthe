package modele;

public class Loup extends Case {
	
	public void action (Aventurier a)
	{
		a.setVp(a.getVp()-10);
		a.setStep(a.getStep()+1);
		a.setLoup(a.getLoup()+1);
	}

}
