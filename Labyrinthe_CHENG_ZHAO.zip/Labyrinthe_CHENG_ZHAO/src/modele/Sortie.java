package modele;

public class Sortie extends Case {
	
	public void action (Aventurier a)
	{
	
	}

}
