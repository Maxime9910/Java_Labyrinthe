package modele;

public class Mage extends Case {
	
	public void action (Aventurier a)
	{
		a.setVp(a.getVp()-5+a.getEau()*2);
		a.setStep(a.getStep()+1);
	}

}
