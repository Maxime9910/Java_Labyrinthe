package modele;

public class Druide extends Case {
	
	public void action (Aventurier a)
	{
		
		if  (a.getSerpent()!=0) {
			a.setVp(a.getVp()+10*a.getSerpent());
		a.setStep(a.getStep()+1);
		a.setDruide(a.getDruide()+1);
		}
		
		if  (a.getSerpent()==0) {
			
		a.setStep(a.getStep()+1);
		a.setDruide(a.getDruide()+1);
		}
		

		
	}

}
