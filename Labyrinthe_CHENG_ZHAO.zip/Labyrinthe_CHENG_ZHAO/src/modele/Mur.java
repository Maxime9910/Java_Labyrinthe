package modele;


/**
 * Classe qui représente un mur.
 */
public class Mur extends Case
{
	/**
	 * Méthode qui définit une action / un changement sur l'aventurier.
	 */
	@Override
	public void action (Aventurier a)
		{
		// Code à compléter !
		System.out.println("Je suis un mur !");
		}

} /*----- Fin de la classe Mur -----*/
