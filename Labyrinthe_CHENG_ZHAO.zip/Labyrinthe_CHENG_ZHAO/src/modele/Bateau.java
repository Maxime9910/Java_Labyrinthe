package modele;

public class  Bateau extends Case {
	public void action (Aventurier a)
	{
	
	a.setBateau(a.getBateau()+1);
	a.setVp(a.getVp()-5+a.getEau()*2);
	a.setStep(a.getStep()+1);
	}

}
