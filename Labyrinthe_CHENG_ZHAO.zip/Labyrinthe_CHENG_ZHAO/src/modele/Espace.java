package modele;


/**
 * Classe qui représente une zone d'espace libre.
 */
public class Espace extends Case
{
	/**
	 * Méthode qui définit une action / un changement sur l'aventurier.
	 */
	@Override
	public void action (Aventurier a)
		{
		
		a.setVp(a.getVp()-2);
		a.setStep(a.getStep()+1);
		
		}

} /*----- Fin de la classe Espace -----*/
