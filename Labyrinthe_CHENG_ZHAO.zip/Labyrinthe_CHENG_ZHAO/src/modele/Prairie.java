package modele;

public class Prairie extends Case {
	public void action (Aventurier a)
	{
		a.setVp(a.getVp()-2);
		a.setStep(a.getStep()+1);
	}
}
