package modele;

public class Voleur extends Case{

	public void action (Aventurier a)
	{
		if(a.getBateau()==1) {
		a.setVp(a.getVp()-10);
		a.setStep(a.getStep()+1);
		a.setVoleur(a.getVoleur()+1);
		}else {
			a.setVp(a.getVp()-10);
			a.setStep(a.getStep()+1);
			
		}
	}
}
