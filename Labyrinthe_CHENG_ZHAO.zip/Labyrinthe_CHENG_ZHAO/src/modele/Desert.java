package modele;

public class Desert extends Case{

	public void action (Aventurier a)
	{
		a.setVp(a.getVp()-6+a.getEau()*2);
		a.setStep(a.getStep()+1);	}
}
