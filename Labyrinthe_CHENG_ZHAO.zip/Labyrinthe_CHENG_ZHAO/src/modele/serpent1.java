package modele;

public class serpent1 extends Case{

	public void action (Aventurier a)
	{
		int druide=a.getDruide();
		if (a.getDruide()!=0) {
		a.setVp(a.getVp()-10+druide*10);
		a.setStep(a.getStep()+1);
		a.setSerpent(a.getSerpent()+1);
		}else {
			a.setVp(a.getVp()-10);
			a.setStep(a.getStep()+1);
			a.setSerpent(a.getSerpent()+1);
		}
		
	}
}

