package modele;


/**
 * Classe qui représente l'aventurier qui traverse le labyrinthe.
 */
public class Aventurier
{
	/*------------*/
	/* Propriétés */
	/*------------*/

	/*----- Sa position dans le labyrinthe -----*/
	private int x;
	private int y;
	private int vp;
	private int step;
	private int cle;
	private int eau;
	private int bateau;
	private int druide;
	private int serpent;
	private int voleur;
	private int loup;
	/*--------------*/
	/* Constructeur */
	/*--------------*/
	

	


	public Aventurier (int x, int y,int vp,int step,int cle,int eau,int bateau,int druide,int serpent,int voleur,int loup )
		{
		this.x = x;
		this.y = y;
		this.vp = vp;
		this.step = step;
		this.cle = cle;
		this.eau = eau;
		this.bateau = bateau;
	    this.druide=druide;
	    this.serpent=serpent;
	    this.voleur=voleur;
		}


	/*----------*/
	/* Méthodes */
	/*----------*/

	
	public int getVoleur() {
		return voleur;
	}


	public void setVoleur(int voleur) {
		this.voleur = voleur;
	}


	public int getSerpent() {
		return serpent;
	}


	public void setSerpent(int serpent) {
		this.serpent = serpent;
	}


	public int getDruide() {
		return druide;
	}


	public void setDruide(int druide) {
		this.druide = druide;
	}

	public int getVp() {
		return vp;
	}


	public void setVp(int vp) {
		this.vp = vp;
	}


	public int getStep() {
		return step;
	}


	public void setStep(int step) {
		this.step = step;
	}


	public int getCle() {
		return cle;
	}


	public void setCle(int cle) {
		this.cle = cle;
	}


	public int getEau() {
		return eau;
	}


	public void setEau(int eau) {
		this.eau = eau;
	}


	public int getBateau() {
		return bateau;
	}


	public void setBateau(int bateau) {
		this.bateau = bateau;
	}
	
	public int getLoup() {
		return loup;
	}


	public void setLoup(int loup) {
		this.loup = loup;
	}


	public int getX () { return this.x; }
	public void setX (int x) { this.x = x; }

	public int getY () { return this.y; }
	public void setY (int y) { this.y = y; }

} /*----- Fin de la classe Aventurier -----*/
