package modele;

public class Ocean extends Case{
	
	public void action (Aventurier a)
	{
		
			
		  if(a.getBateau()!=0&&a.getVoleur()==0) {
		  a.setVp(a.getVp()-10+a.getBateau()*7);
		  a.setStep(a.getStep()+1);
		  }
		  
		  if(a.getBateau()!=0&&a.getVoleur()!=0) {
			  a.setVp(a.getVp()-10);
			  a.setStep(a.getStep()+1);
			  }
		  
		  if(a.getBateau()==0) {
			  a.setVp(a.getVp()-10);
			  a.setStep(a.getStep()+1);
			  }
		  
		  
		}
	}
	


