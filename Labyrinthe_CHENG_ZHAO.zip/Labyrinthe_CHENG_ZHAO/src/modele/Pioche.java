package modele;

public class Pioche extends Case{

	public void action (Aventurier a)
	{
	// Code à compléter !
	System.out.println("Je suis un mur !");
	}
}
