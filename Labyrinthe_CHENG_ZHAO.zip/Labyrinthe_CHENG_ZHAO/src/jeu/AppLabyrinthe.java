package jeu;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream.GetField;
import java.util.Scanner;

import javax.management.remote.SubjectDelegationPermission;

import modele.Aventurier;
import modele.Espace;
import modele.Labyrinthe;
import modele.Mur;
import modele.Prairie;
import modele.*;
import vue.Vue;


/**
 * Application de l'aventurier et du labyrinthe.
 * 
 * Cette classe permet de charger le jeu et de le lancer.
 */
public class AppLabyrinthe
{
	/**
	 * Noms des fichiers contenant des labyrinthes.
	 */
	private static final String Facile = "data" + File.separator + "labyrinthe_1.csv";
	private static final String Difficile = "data" + File.separator + "labyrinthe_2.csv";
	


	/**
	 * Chargement du labyrinthe et de l'aventurier.
	 *
	 * A partir d'un fichier csv, cette méthode crée le labyrinthe et
	 * l'aventurier sur la case de départ du labyrinthe.
	 */
	public static Labyrinthe chargeLabyrinthe (String fichier)
		{
		Labyrinthe laby = null;

		try (Scanner scanner = new Scanner(new FileInputStream(fichier)))
			{
			/*----- Lecture de la taille du labyrinthe -----*/
			int taille = Integer.valueOf(scanner.nextLine());

			/*----- Initialisation du labyrinthe -----*/
			laby = new Labyrinthe(taille);

			/*----- Lecture du fichier et des types de cases composant le labyrinthe -----*/
			for (int i=0; i<taille; i++)
				{
				/*----- Lecture d'une ligne du fichier -----*/
				String[] liste = scanner.nextLine().trim().split(";");
		
               
				int type_case;
				for (int j=0; j<taille; j++)
					{
					type_case = Integer.valueOf(liste[j]);

					/*----- Type 0 --> "Espace" -----*/
					if (type_case == 0) laby.setCase(i, j, new Espace());

					/*----- Type 1 --> "Mur" -----*/
					if (type_case == 1) laby.setCase(i, j, new Mur());
					
					/*----- Type 2 --> "Prairie" -----*/
					if (type_case == 2) laby.setCase(i, j, new Prairie());
					
					/*----- Type 3 --> "Loup" -----*/
					if (type_case == 3) laby.setCase(i, j, new Loup());

					/*----- Type 4 --> "Océan" -----*/
					if (type_case == 4) laby.setCase(i, j, new Ocean());
					
					/*----- Type 5 --> "Bateau" -----*/
					if (type_case == 5) laby.setCase(i, j, new Bateau ());
					
					/*----- Type 6 --> "Desert" -----*/
					if (type_case == 6) laby.setCase(i, j, new Desert());

					/*----- Type 7 --> "Eau" -----*/
					if (type_case == 7) laby.setCase(i, j, new Eau());
					
					/*----- Type 8 --> "Porte" -----*/
					if (type_case == 8) laby.setCase(i, j, new Porte());
					
					/*----- Type 9 --> "Clé" -----*/
					if (type_case == 9) laby.setCase(i, j, new Cle());

					/*----- Type 10 --> "Pioche" -----*/
					
					if (type_case == 10) laby.setCase(i, j, new Pioche());
					/*----- Type 11 --> "Serpent" -----*/
					if (type_case == 11) laby.setCase(i, j, new Serpent());
					
					/*----- Type 12 --> "Soigneur" -----*/
					if (type_case == 12) laby.setCase(i, j, new Soigneur());

					/*----- Type 13 --> "Voleur" -----*/
					if (type_case == 13) laby.setCase(i, j, new Voleur());
					
					/*----- Type 14 --> "Druide" -----*/
					if (type_case == 14) laby.setCase(i, j, new Druide());
					
					/*----- Type 15 --> "Mage" -----*/
					if (type_case == 15) laby.setCase(i, j, new Mage());
					
					
					
					
					/*----- Type 16 --> "Espace de départ" et "Aventurier" -----*/
					if (type_case == 16)
						{
						laby.setCase(i, j, new Espace());
						laby.setAventurier(new Aventurier(i, j,200,0,0,0,0,0,0,0,0));
						
						}
					/*----- Type 17 --> "Sortie" -----*/
					if (type_case == 17) laby.setCase(i, j, new Sortie());
					}
				}
			}
		catch (FileNotFoundException ex)
			{
			System.err.println("Erreur lors de la lecture du fichier : " + fichier + " - " + ex.getMessage());
			}

		return laby;
		}


	/*---------------------*/
	/* Programme principal */
	/*---------------------*/

	public static void main (String[] s) throws InterruptedException
		{
		/*----- Chargement du labyrinthe -----*/
		Labyrinthe labyrinthe1 = chargeLabyrinthe(Facile);
		Labyrinthe labyrinthe2 = chargeLabyrinthe(Difficile);
		

		/*----- Création de la fenêtre de visualisation du labyrinthe et affichage -----*/
		new Vue(120, 0, labyrinthe1,labyrinthe1,labyrinthe2);
		}

} /*----- Fin de ma classe AppLabyrinthe -----*/
