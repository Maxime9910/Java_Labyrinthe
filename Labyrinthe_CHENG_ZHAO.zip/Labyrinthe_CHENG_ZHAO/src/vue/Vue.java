package vue;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


import modele.Aventurier;
import modele.Desert;
import modele.Espace;
import modele.Labyrinthe;
import modele.Ocean;
import modele.loup1;
import modele.serpent1;
import modele.voleur1;
import vue.Vue.Etat;


/**
 * Fenêtre de visualisation du labyrinthe.
 */
public class Vue extends JFrame
{
	/*------------*/
	/* Propriétés */
	/*------------*/

	/**
	 * Référence vers le labyrinthe que la classe Vue va visualiser.
	 */
	private Labyrinthe labyrinthe;
	private final Labyrinthe Facile;
	private final Labyrinthe Difficile;

	/*----- Barre d'état de la fenêtre -----*/
	private final JLabel barre_etat;
	
	/*----- MenuBar de la fenêtre -----*/
	private final JMenuBar menuBar;

	/*----- Zone de dessin -----*/
	Dessin dessin;
	
	Etat etat;
	
	long startTime ;
	long endTime=480*1000;
	
	boolean start = false;
	boolean stop = true;
	
	Image ocean= new ImageIcon("image/ocean.jpg").getImage();
	Image desert= new ImageIcon("image/desert.jpg").getImage();
	Image prairie= new ImageIcon("image/prairie.jpg").getImage();
	Image espace= new ImageIcon("image/espace.jpg").getImage();
	Image mage= new ImageIcon("image/mage.jpg").getImage();
	Image bateau= new ImageIcon("image/bateau.jpg").getImage();
	Image porte= new ImageIcon("image/porte.jpg").getImage();
	Image mur= new ImageIcon("image/mur.jpg").getImage();
	Image cle= new ImageIcon("image/cle.jpg").getImage();
	Image druide= new ImageIcon("image/druide.jpg").getImage();
	Image soigneur= new ImageIcon("image/soigneur.jpg").getImage();
	Image eau= new ImageIcon("image/eau.jpg").getImage();
	Image sortie= new ImageIcon("image/sortie.jpg").getImage();
	Image player= new ImageIcon("image/player.jpg").getImage();
	Image serpent= new ImageIcon("image/serpent.jpg").getImage();
	Image loup= new ImageIcon("image/loup.jpg").getImage();
	Image voleur= new ImageIcon("image/voleur.jpg").getImage();
	
	

	/*--------------*/
	/* Constructeur */
	/*--------------*/

	public Vue (int x, int y, Labyrinthe labyrinthe, Labyrinthe Facile, Labyrinthe Difficile)
	{
	/*----- Lien avec le labyrinthe -----*/
	this.labyrinthe = labyrinthe;
	this.Facile = Facile;
	this.Difficile = Difficile;

		/*----- Paramètres de la fenêtre -----*/
		this.setTitle("Labyrinthe");
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocation(x,y);
		this.setLayout(new BorderLayout());

		/*----- Zone de dessin -----*/
		this.dessin = new Dessin(620);
		this.dessin.setFocusable(true);

		/*----- Attachement des écouteurs des évènements souris et clavier -----*/
		this.dessin.addMouseListener(this.dessin);
		this.dessin.addMouseMotionListener(this.dessin);
		this.dessin.addKeyListener(this.dessin);
		this.add(this.dessin, BorderLayout.CENTER);

		/*----- Barre d'état de la fenêtre -----*/
		this.barre_etat = new JLabel("Barre d'état");
		this.add(this.barre_etat, BorderLayout.SOUTH);
		
		this.etat = new Etat(380,620);
		this.etat.setFocusable(true);
		this.add(this.etat, BorderLayout.EAST);
		

		/*----- MenuBar de la fenêtre -----*/
		this.menuBar = new JMenuBar();
		this.setJMenuBar(menuBar);
		JMenu menu1 = new JMenu("Jeu");
		JMenu menu2 = new JMenu("Maps");
		
		menuBar.add(menu1);
		menuBar.add(menu2);
		
		JMenuItem item1 = new JMenuItem ("Start");
		JMenuItem item2 = new JMenuItem ("Exit");
		
		
		JMenuItem item3 = new JMenuItem ("Facile");
		JMenuItem item4 = new JMenuItem ("Difficile");
		
		menu1.add(item1);
		menu1.add(item2);
		menu2.add(item3);
		menu2.add(item4);
		
		
		item1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == item1) {
					
					start = true;
					if(stop ==true) {
						startTime= System.currentTimeMillis();
						}
					item1.setEnabled(false);
					item2.setEnabled(true);
					item4.setEnabled(false);
					item3.setEnabled(false);
					
				}
			}
		});
		
		item2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
		item3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				setLabyrinthe(Facile);
				
				
			}
			
		});
		
		item4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				setLabyrinthe(Difficile);
				
				
			}
			
		});
		
		

		
		
		
		/*----- Pour ajuster la fenêtre à son contenu et la rendre visible -----*/
		this.pack();
		this.setVisible(true);
		}


	/*----------------*/
	/* Classe interne */
	/*----------------*/
		
	
	public Labyrinthe getLabyrinthe() {return labyrinthe;}
	public void setLabyrinthe(Labyrinthe labyrinthe) {this.labyrinthe = labyrinthe;}
	
	
	
	
	class Etat extends JPanel
	{
	/*----- Propriétés de la classe interne -----*/
	int a;
	int b;
	
	public Etat (int a, int b)
		{
		/*----- Initialisation des données -----*/
		this.a = a;
		this.b = b;
		
		/*----- Paramètre du JPanel -----*/
		this.setPreferredSize(new Dimension(this.a, this.b));
		}
	public void paintComponent (Graphics g)
	{
		super.paintComponent(g); 
		g.drawString("Etat de player : ",25,50);

		/*----- Affichage de l'aventurier -----*/
		Aventurier aventurier = labyrinthe.getAventurier();
		
		long t = ((endTime - (System.currentTimeMillis()-startTime))/1000);
		long m = t/60;
		long s = t-m*60;
		
		
		String Time;
		if (t >0) {
			Time = "Temps reste : " + m + "m" + s + "s";
			g.drawString(Time,25,25);
		}
		
		
		String step;
		step = "nombre de Step : " + aventurier.getStep();
		g.drawString(step,25,75);
		
		String VP;
		VP = "VP : " + aventurier.getVp()+" / 200";
		g.drawString(VP,25,100);
		
		String cle;
		if (aventurier.getCle()>0) {
		cle = "nombre de Clé : " + aventurier.getCle() ;
		g.drawString(cle,25,125);
		}
		
		String bateau;
		if (aventurier.getBateau()>0) {
			bateau = "nombre de Bateau : " + aventurier.getBateau();
			g.drawString(bateau,25,150);
		}
		
		String eau;
		if (aventurier.getEau()>0) {
			eau = "nombre d'eau : " + aventurier.getEau();
			g.drawString(eau,25,175);
		}
		
		String voleur;
		if (aventurier.getVoleur()>0) {
			System.out.println(aventurier.getVoleur());
			voleur = "nombre de voleur : " + aventurier.getVoleur();
			g.drawString(voleur,25,200);
		}
		
		String druide;
		if (aventurier.getDruide()>0) {
			System.out.println(aventurier.getDruide());
			druide = "druide : " + aventurier.getDruide();
			g.drawString(druide,25,225);
		}
		
		String serpent;
		if (aventurier.getSerpent()>0) {
			System.out.println(aventurier.getSerpent());
			serpent = " Nombre de morsures de serpent venimeux : " + aventurier.getSerpent();
			g.drawString(serpent,25,250);
		}
		
		String loup;
		if (aventurier.getLoup()>0) {
			System.out.println(aventurier.getLoup());
			loup = "Nombre de morsures de loups : " + aventurier.getLoup();
			g.drawString(loup,25,275);
		}
		
			
		
		
		
		
		String intro0,intro1, intro2, intro3, intro4, intro5, intro6, intro7, intro8, intro9, intro10, intro11, intro12;
	     intro0 = "----------------------INTRODUCTION DU JEU----------------------";
	     intro12= "-----> Veuillez sélectionner la difficulté du jeu dans Maps !";
	     intro1 = "-----> Il faut trouver la sortie en bas dans 8 minutes !";
	     intro2 = "-----> BON COURAGE!!!";
	     intro3 = "■zone prairie (VP-2): attention aux loups!";
	     intro4 = "■zone désert (VP-6) : attention aux serpents!";
	     intro5 = "■zone océan (VP-10) : attention aux voleurs! ";
	     intro6 = "■(VP+2 pour une bouteille d'eau supplémentaire dans le désert)";
	     intro7 = "■(VP-3 avec bateau dans l'océan )";
	     intro8 = "■portes en bois : nécessite une clé pour passer";
	     intro9 = "■petite bouteille verte : antidote! (contre les serpents venimeux)" ;
	     intro10 = "■cercles rouges : mage! (transfert de joueurs)";
	     intro11 = "■croix verte : soigneur (VP+20)";


	     g.drawString(intro0, 25, 300);
	     g.drawString(intro12, 25, 325);
	     g.drawString(intro1, 25, 350);
	     g.drawString(intro2, 25, 375);
	     g.drawString(intro3, 25, 400);
	     g.drawString(intro4, 25, 425);
	     g.drawString(intro5, 25, 450);
	     g.drawString(intro6, 25, 475);
	     g.drawString(intro7, 25, 500);
	     g.drawString(intro8, 25, 525);
	     g.drawString(intro9, 25, 550);
	     g.drawString(intro10, 25, 575);
	     g.drawString(intro11, 25, 600);

	       
			
				
		repaint();
		if (t==0) {
			JOptionPane.showMessageDialog(this, "Vous êtes mort !");
			
			System.exit(0);
			
		}
		
		
				
		
		}
	
	
	
	
		
  }





	class Dessin extends JPanel implements KeyListener, MouseListener, MouseMotionListener
		{
		/*----- Propriétés de la classe interne -----*/
		int largeur;
		int taille_case;

		/*----- Constructeur de la classe interne -----*/
		public Dessin (int larg)
			{
			/*----- Initialisation des données -----*/
			this.taille_case = larg / labyrinthe.getTaille();
			this.largeur = this.taille_case * labyrinthe.getTaille();

			/*----- Paramètre du JPanel -----*/
			this.setPreferredSize(new Dimension(this.largeur, this.largeur));
			}


		/**
		 * Méthode qui permet de dessiner ou redessinner le labyrinthe lorsque
		 * la méthode repaint() est appelée sur la classe Dessin.
		 */
		@Override
		public void paint (Graphics g)
			{
			/*----- On efface le dessin en entier -----*/
			g.setColor(Color.LIGHT_GRAY);
			g.fillRect(0,0,this.largeur,this.largeur);

			/*----- Affichage des cases du labyrinthe -----*/
			for (int i=0; i < labyrinthe.getTaille(); i++)
				for (int j=0; j < labyrinthe.getTaille(); j++)
					{
					/*----- Couleur de la case -----*/
					if (labyrinthe.getCase(i,j).getClassName().equals("Mur"))      g.drawImage(mur,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("Espace"))   g.drawImage(espace,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("Prairie"))  g.drawImage(prairie,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("Loup"))    g.drawImage(prairie,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("Ocean"))    g.drawImage(ocean,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("Bateau"))   g.drawImage(bateau,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("Desert"))   g.drawImage(desert,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("Eau"))     g.drawImage(eau,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("Porte"))    g.drawImage(porte,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("Cle"))     g.drawImage(cle,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("Serpent"))   g.drawImage(desert,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("Soigneur")) g.drawImage(soigneur,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("Voleur"))   g.drawImage(ocean,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("Druide"))   g.drawImage(druide,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("Mage"))    g.drawImage(mage,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("Sortie"))    g.drawImage(sortie,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("serpent1"))    g.drawImage(serpent,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("loup1"))    g.drawImage(loup,taille_case*j, taille_case*i, taille_case,this.taille_case,this);
					if (labyrinthe.getCase(i,j).getClassName().equals("voleur1"))    g.drawImage(voleur,taille_case*j, taille_case*i, taille_case,this.taille_case,this);

					/*----- Affichage de la case sous forme d'un rectangle plein -----*/
					
					}

			/*----- Affichage de l'aventurier -----*/
			Aventurier aventurier = labyrinthe.getAventurier();

			 g.drawImage(player,taille_case*aventurier.getY(), taille_case*aventurier.getX(), taille_case,this.taille_case,this);
			
			
			repaint();
			}
            
		
		
	


		/**
		 * Gestion des interactions souris et clavier sur le labyrinthe.
		 */
		@Override
		public void mouseClicked (MouseEvent e)
			{
			/*----- Lecture de la position de la souris lors du clic sur l'objet Dessin -----*/
			int x = e.getX();
			int y = e.getY();

			/*----- Recherche des coordonnées de la case du labyrinthe sur laquelle le aventurier a cliqué -----*/
			int ligne = y / this.taille_case;
			int colonne = x / this.taille_case;

			/*----- On regarde si l'aventurier est sur la case sur laquelle on vient de cliquer -----*/
			String msgAventurier = "";
			if (labyrinthe.getAventurier().getX() == ligne && labyrinthe.getAventurier().getY() == colonne)
				msgAventurier = "\nL'aventurier est sur cette case.";

			/*----- Etat de la case -----*/
			
			}

		@Override
		public void mousePressed (MouseEvent e) { }

		@Override
		public void mouseReleased (MouseEvent e) { }

		@Override
		public void mouseEntered (MouseEvent e) { }

		@Override
		public void mouseExited (MouseEvent e) { }

		@Override
		public void mouseDragged (MouseEvent e) { 
			
		}
		
		

		@Override
		public void mouseMoved (MouseEvent e)
			{
			barre_etat.setText(" Position de la souris : " + e.getX() + " " + e.getY());
			}

		@Override
		public void keyTyped (KeyEvent e) { }

		@Override
		public void keyPressed (KeyEvent e) { }

		@Override
		public void keyReleased (KeyEvent e)
			{
			
				if (!start && e.getKeyCode()!=KeyEvent.VK_ENTER) {
					JOptionPane.showMessageDialog(this, "Il faut cliquer 'Start' dans le jeu SVP !");
					return;
				}
			
			/**
			 * Déplacement de l'aventurier dans le labyrinthe.
			 */
			Aventurier aventurier = labyrinthe.getAventurier();
			
			int posX = labyrinthe.getAventurier().getX();
			int posY = labyrinthe.getAventurier().getY();
			long t = ((endTime - (System.currentTimeMillis()-startTime))/1000);
			long m = t/60;
			long s = t-m*60;
			long ms=  endTime-(System.currentTimeMillis()-startTime);
			/*----- On déclenche l'action de la case sur laquelle est l'aventurier -----*/
			
			/*----- Vers le bas -----*/
		  if (e.getKeyCode() == KeyEvent.VK_DOWN) {
		
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("Espace")) {
		     labyrinthe.getAventurier().setX(posX + 1);
		     labyrinthe.getCase(posX + 1, posY).action(aventurier);
		  }
		
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("Ocean")) {
		     labyrinthe.getAventurier().setX(posX + 1);
		     labyrinthe.getCase(posX + 1, posY).action(aventurier);
		  }
		
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("Prairie")) {
		     labyrinthe.getAventurier().setX(posX + 1);
		     labyrinthe.getCase(posX + 1, posY).action(aventurier);
		  }
		
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("Desert")) {
		     labyrinthe.getAventurier().setX(posX + 1);
		     labyrinthe.getCase(posX + 1, posY).action(aventurier);
		  }
		
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("Bateau")) {
		     labyrinthe.getAventurier().setX(posX + 1);
		     labyrinthe.getCase(posX + 1, posY).action(aventurier);
		     JOptionPane.showMessageDialog(this, "Vous avez acquis un bateau！");
		     labyrinthe.setCase(posX + 1,posY, new Desert());
		  }
		
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("Eau")) {
		     labyrinthe.getAventurier().setX(posX + 1);
		     labyrinthe.getCase(posX + 1, posY).action(aventurier);
		     JOptionPane.showMessageDialog(this, "Vous avez acquis une bouteille d'eau！");
		     labyrinthe.setCase(posX + 1,posY, new Desert());
		  }
		  
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("loup1")) {
			     labyrinthe.getAventurier().setX(posX + 1);
			     labyrinthe.getCase(posX + 1, posY).action(aventurier);
			     JOptionPane.showMessageDialog(this, "Vous avez été mordu par un loup! \n VP-10");
			     
			  }
		
		
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("Loup")) {
		     labyrinthe.getAventurier().setX(posX + 1);
		     labyrinthe.getCase(posX + 1, posY).action(aventurier);
		     labyrinthe.setCase(posX + 1,posY, new loup1());
		     JOptionPane.showMessageDialog(this, "Vous avez été mordu par un loup! \n VP-10");
		     
		  }
		  
		  
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("serpent1")) {
			     labyrinthe.getAventurier().setX(posX + 1);
			     labyrinthe.getCase(posX + 1, posY).action(aventurier);
			     
			     if(aventurier.getDruide()==0) {
			     JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \n VP-10");
			  }else {
				  JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \nMais vous avez l'antidote.");
			  }
			  }
		  
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("Serpent")) {
		     labyrinthe.getAventurier().setX(posX + 1);
		     labyrinthe.getCase(posX + 1, posY).action(aventurier);
		     labyrinthe.setCase(posX + 1,posY, new serpent1());
		     if(aventurier.getDruide()==0) {
		     JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \n VP-10");
		  }else {
			  JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \nMais vous avez l'antidote.");
		  }
		  }
		  
		
		
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("Soigneur")) {
		     labyrinthe.getAventurier().setX(posX + 1);
		     labyrinthe.getCase(posX + 1, posY).action(aventurier);
		
		     JOptionPane.showMessageDialog(this, "Vous avez été traité par un Soigneur！"+"\n(VP + 20)");
		     labyrinthe.setCase(posX + 1,posY, new Desert());
		  }
		
		  
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("Druide")) {
			  labyrinthe.getAventurier().setX(posX + 1);
			  labyrinthe.getCase(posX + 1, posY).action(aventurier);
			  
			  JOptionPane.showMessageDialog(this, "Le druide vous a donné une fiole d'antidote.");
			  labyrinthe.setCase(posX + 1, posY, new Desert());
			}
		  

		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("voleur1")) {
			     labyrinthe.getAventurier().setX(posX + 1);
			     labyrinthe.getCase(posX + 1, posY).action(aventurier);
			     
			     if(aventurier.getBateau()==1) {
			     JOptionPane.showMessageDialog(this, "Vous êtes attaqué par des pirates et votre bateau coule.");
			     
			     }
			  
			  }

		
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("Voleur")) {
		     labyrinthe.getAventurier().setX(posX + 1);
		     labyrinthe.getCase(posX + 1, posY).action(aventurier);
		     
		     if(aventurier.getBateau()==1) {
		     JOptionPane.showMessageDialog(this, "Vous êtes attaqué par des pirates et votre bateau coule.");
		     labyrinthe.setCase(posX + 1, posY, new voleur1());
		     }
		  
		  }
		
		  
			
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("Mage")) {
			  labyrinthe.getAventurier().setY(16);
			     labyrinthe.getAventurier().setX(11);
		     labyrinthe.getCase(11, 16).action(aventurier);
		     JOptionPane.showMessageDialog(this, "Vous êtes transporté dans un autre lieu par le mage.");
		  }
		
		  
		
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("Cle")) {
		     labyrinthe.getAventurier().setX(posX + 1);
		     labyrinthe.getCase(posX + 1, posY).action(aventurier);
		     JOptionPane.showMessageDialog(this, "Vous avez trouvé un clé！");
		     labyrinthe.setCase(posX + 1,posY, new Desert());
		  }
		  
		  if (labyrinthe.getCase(posX + 1, posY).getClassName().equals("Porte")) {
		       if (labyrinthe.getCase(15, 16).getClassName().equals("Desert")) {
		          labyrinthe.getAventurier().setX(posX + 1);
		          labyrinthe.getCase(posX + 1, posY).action(aventurier);
		          JOptionPane.showMessageDialog(this, "Vous avez ouvert une porte!");
		          labyrinthe.setCase(posX + 1, posY, new Desert());
		       } else {
		          JOptionPane.showMessageDialog(this, "Vous n'avez pas de clé pour ouvrir la porte！");
		       }
		    }
		  
		  if (labyrinthe.getCase(posX+1,posY).getClassName().equals("Sortie")){
				labyrinthe.getAventurier().setX(posX+1);
				JOptionPane.showMessageDialog(this, "Félicitations, vous avez terminé le défi !"
						+ "\n Vous avez utilisé :" + aventurier.getStep() + " coups ! "
						+ "\n il reste  :" + aventurier.getVp() + " VP ! "
						+" \n Il reste : " + m + "m" + s + "s");
				System.exit(0);
				}
			
		
		  }
		  
		
		
		
		/*----- Vers le haut -----*/
		if (e.getKeyCode() == KeyEvent.VK_UP) {
			 
					if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("Espace")) {
					     labyrinthe.getAventurier().setX(posX - 1);
					     labyrinthe.getCase(posX - 1, posY).action(aventurier);
					  }
					
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("Ocean")) {
					     labyrinthe.getAventurier().setX(posX - 1);
					     labyrinthe.getCase(posX - 1, posY).action(aventurier);
					  }
					
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("Prairie")) {
					     labyrinthe.getAventurier().setX(posX - 1);
					     labyrinthe.getCase(posX - 1, posY).action(aventurier);
					  }
					
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("Desert")) {
					     labyrinthe.getAventurier().setX(posX - 1);
					     labyrinthe.getCase(posX - 1, posY).action(aventurier);
					  }
					
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("Bateau")) {
					     labyrinthe.getAventurier().setX(posX - 1);
					     labyrinthe.getCase(posX - 1, posY).action(aventurier);
					     JOptionPane.showMessageDialog(this, "Vous avez acquis un bateau！");
					     labyrinthe.setCase(posX - 1,posY, new Desert());
					  }
					
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("Eau")) {
					     labyrinthe.getAventurier().setX(posX - 1);
					     labyrinthe.getCase(posX - 1, posY).action(aventurier);
					     JOptionPane.showMessageDialog(this, "Vous avez acquis une bouteille d'eau！");
					     labyrinthe.setCase(posX - 1,posY, new Desert());
					  }
					
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("loup1")) {
						     labyrinthe.getAventurier().setX(posX - 1);
						     labyrinthe.getCase(posX - 1, posY).action(aventurier);
						     JOptionPane.showMessageDialog(this, "Vous avez été mordu par un loup! \n VP-10");
						  }
					  
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("Loup")) {
					     labyrinthe.getAventurier().setX(posX - 1);
					     labyrinthe.getCase(posX - 1, posY).action(aventurier);
					     labyrinthe.setCase(posX - 1,posY, new loup1());
					     JOptionPane.showMessageDialog(this, "Vous avez été mordu par un loup! \n VP-10");
					  }
					  
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("serpent1")) {
						     labyrinthe.getAventurier().setX(posX - 1);
						     labyrinthe.getCase(posX - 1, posY).action(aventurier);
						     if(aventurier.getDruide()==0) {
							     JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \n VP-10");
							  }else {
								  JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \nMais vous avez l'antidote.");
							  }
							
						  }

					
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("Serpent")) {
					     labyrinthe.getAventurier().setX(posX - 1);
					     labyrinthe.getCase(posX - 1, posY).action(aventurier);
					     labyrinthe.setCase(posX - 1,posY, new serpent1());
					     if(aventurier.getDruide()==0) {
						     JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \n VP-10");
						  }else {
							  JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \nMais vous avez l'antidote.");
						  }
						
					  }
					  
					  					
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("Soigneur")) {
					     labyrinthe.getAventurier().setX(posX - 1);
					     labyrinthe.getCase(posX - 1, posY).action(aventurier);
					     
					
					     JOptionPane.showMessageDialog(this, "Vous avez été traité par un Soigneur！"+"\n(VP + 20)");
					     labyrinthe.setCase(posX - 1,posY, new Desert());
					  }
					
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("Druide")) {
					     labyrinthe.getAventurier().setX(posX - 1);
					     labyrinthe.getCase(posX - 1, posY).action(aventurier);
					     JOptionPane.showMessageDialog(this, "Le druide vous a donné une fiole d'antidote.");
					     labyrinthe.setCase(posX - 1,posY, new Desert());
					  }
					  
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("voleur1")) {
						     labyrinthe.getAventurier().setX(posX - 1);
						     labyrinthe.getCase(posX - 1, posY).action(aventurier);
						     
						     if(aventurier.getBateau()==1) {
						     JOptionPane.showMessageDialog(this, "Vous êtes attaqué par des pirates et votre bateau coule.");
						    
						  }

						  
						  }
					
					
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("Voleur")) {
						     labyrinthe.getAventurier().setX(posX - 1);
						     labyrinthe.getCase(posX - 1, posY).action(aventurier);
						     
						     if(aventurier.getBateau()==1) {
						     JOptionPane.showMessageDialog(this, "Vous êtes attaqué par des pirates et votre bateau coule.");
						     labyrinthe.setCase(posX - 1,posY, new voleur1());
						  }

						  
						  }
					  
					
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("Mage")) {
						  labyrinthe.getAventurier().setY(16);
						     labyrinthe.getAventurier().setX(11);
					     labyrinthe.getCase(11, 16).action(aventurier);
					     JOptionPane.showMessageDialog(this, "Vous êtes transporté dans un autre lieu par le mage.");
					  }
					
					  
					
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("Cle")) {
					     labyrinthe.getAventurier().setX(posX - 1);
					     labyrinthe.getCase(posX - 1, posY).action(aventurier);
					     JOptionPane.showMessageDialog(this, "Vous avez trouvé un clé！");
					     labyrinthe.setCase(posX - 1,posY, new Desert());
					  }
					  
					  if (labyrinthe.getCase(posX - 1, posY).getClassName().equals("Porte")) {
					       if (labyrinthe.getCase(15, 16).getClassName().equals("Desert")) {
					          labyrinthe.getAventurier().setX(posX - 1);
					          labyrinthe.getCase(posX - 1, posY).action(aventurier);
					          JOptionPane.showMessageDialog(this, "Vous avez ouvert une porte!");
					          labyrinthe.setCase(posX - 1, posY, new Desert());
					       } else {
					          JOptionPane.showMessageDialog(this, "Vous n'avez pas de clé pour ouvrir la porte！");
					       }
					    }


		}
		
		
		
		  /*----- Vers la droite -----*/
		  if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("Espace")) {
				     labyrinthe.getAventurier().setY(posY + 1);
				     labyrinthe.getCase(posX, posY + 1).action(aventurier);
				  }
				
				  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("Ocean")) {
				     labyrinthe.getAventurier().setY(posY + 1);
				     labyrinthe.getCase(posX, posY + 1).action(aventurier);
				  }
				
				  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("Prairie")) {
				     labyrinthe.getAventurier().setY(posY + 1);
				     labyrinthe.getCase(posX, posY + 1).action(aventurier);
				  }
				
				  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("Desert")) {
				     labyrinthe.getAventurier().setY(posY + 1);
				     labyrinthe.getCase(posX, posY + 1).action(aventurier);
				  }
				
				  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("Bateau")) {
				     labyrinthe.getAventurier().setY(posY + 1);
				     labyrinthe.getCase(posX, posY + 1).action(aventurier);
				     JOptionPane.showMessageDialog(this, "Vous avez acquis un bateau！");
				     labyrinthe.setCase(posX,posY + 1, new Desert());
				  }
				
				  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("Eau")) {
				     labyrinthe.getAventurier().setY(posY + 1);
				     labyrinthe.getCase(posX, posY + 1).action(aventurier);
				     JOptionPane.showMessageDialog(this, "Vous avez acquis une bouteille d'eau！");
				     labyrinthe.setCase(posX,posY + 1, new Desert());
				  }
				  
				  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("loup1")) {
					     labyrinthe.getAventurier().setY(posY + 1);
					     labyrinthe.getCase(posX, posY + 1).action(aventurier);
					     
					     JOptionPane.showMessageDialog(this, "Vous avez été mordu par un loup! \n VP-10");
					  }
				
				  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("Loup")) {
				     labyrinthe.getAventurier().setY(posY + 1);
				     labyrinthe.getCase(posX, posY + 1).action(aventurier);
				     labyrinthe.setCase(posX,posY + 1, new loup1());
				     JOptionPane.showMessageDialog(this, "Vous avez été mordu par un loup! \n VP-10");
				  }
				  
				  
				
				  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("serpent1")) {
				     labyrinthe.getAventurier().setY(posY + 1);
				     labyrinthe.getCase(posX, posY + 1).action(aventurier);
				     
				     if(aventurier.getDruide()==0) {
					     JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \n VP-10");
					  }else {
						  JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \nMais vous avez l'antidote.");
					  }
					
				  }
				  
				  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("Serpent")) {
					     labyrinthe.getAventurier().setY(posY + 1);
					     labyrinthe.getCase(posX, posY + 1).action(aventurier);
					     labyrinthe.setCase(posX,posY + 1, new serpent1());
					     if(aventurier.getDruide()==0) {
						     JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \n VP-10");
						  }else {
							  JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \nMais vous avez l'antidote.");
						  }
						
					  }
				
				  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("Soigneur")) {
				     labyrinthe.getAventurier().setY(posY + 1);
				     labyrinthe.getCase(posX, posY + 1).action(aventurier);
				
				     JOptionPane.showMessageDialog(this, "Vous avez été traité par un Soigneur！"+"\n(VP + 20)");
				     labyrinthe.setCase(posX,posY + 1, new Desert());
				  }
				
				  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("Druide")) {
				     labyrinthe.getAventurier().setY(posY + 1);
				     labyrinthe.getCase(posX, posY + 1).action(aventurier);
				     JOptionPane.showMessageDialog(this, "Le druide vous a donné une fiole d'antidote.");
				     labyrinthe.setCase(posX,posY + 1, new Desert());
				     
				     
				  }
				  
				  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("voleur1")) {
					     labyrinthe.getAventurier().setX(posY + 1);
					     labyrinthe.getCase(posX, posY + 1).action(aventurier);
					     
					     if(aventurier.getBateau()==1) {
					     JOptionPane.showMessageDialog(this, "Vous êtes attaqué par des pirates et votre bateau coule.");
					     
					  }
					  }
				
				
				  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("Voleur")) {
					     labyrinthe.getAventurier().setX(posY + 1);
					     labyrinthe.getCase(posX, posY + 1).action(aventurier);
					     
					     if(aventurier.getBateau()==1) {
					     JOptionPane.showMessageDialog(this, "Vous êtes attaqué par des pirates et votre bateau coule.");
					     labyrinthe.setCase(posX,posY + 1, new voleur1());
					  }
					  }
				
				  
				  
				  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("Mage")) {
				     labyrinthe.getAventurier().setY(16);
				     labyrinthe.getAventurier().setX(11);
				     labyrinthe.getCase(11,16).action(aventurier);
				     JOptionPane.showMessageDialog(this, "Vous êtes transporté dans un autre lieu par le mage.");
				  }
				  
				  if (labyrinthe.getCase(posX, posY + 1).getClassName().equals("Porte")) {
				       if (labyrinthe.getCase(15, 16).getClassName().equals("Desert")) {
				          labyrinthe.getAventurier().setY(posY + 1);
				          labyrinthe.getCase(posX, posY + 1).action(aventurier);
				          JOptionPane.showMessageDialog(this, "Vous avez ouvert une porte!");
				          labyrinthe.setCase(posX, posY + 1, new Desert());
				       } else {
				          JOptionPane.showMessageDialog(this, "Vous n'avez pas de clé pour ouvrir la porte！");
				       }
				    }

				  
				
				  
				  
				 

		  }
		  
		
		
				  /*----- Vers la gauche -----*/
				  if (e.getKeyCode() == KeyEvent.VK_LEFT) {
				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("Espace")) {
				       labyrinthe.getAventurier().setY(posY - 1);
				       labyrinthe.getCase(posX, posY - 1).action(aventurier);
				    }

				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("Ocean")) {
				       labyrinthe.getAventurier().setY(posY - 1);
				       labyrinthe.getCase(posX, posY - 1).action(aventurier);
				    }

				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("Prairie")) {
				       labyrinthe.getAventurier().setY(posY - 1);
				       labyrinthe.getCase(posX, posY - 1).action(aventurier);
				    }

				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("Desert")) {
				       labyrinthe.getAventurier().setY(posY - 1);
				       labyrinthe.getCase(posX, posY - 1).action(aventurier);
				    }

				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("Bateau")) {
				       labyrinthe.getAventurier().setY(posY - 1);
				       labyrinthe.getCase(posX, posY - 1).action(aventurier);
				       JOptionPane.showMessageDialog(this, "Vous avez acquis un bateau！");
				       labyrinthe.setCase(posX, posY - 1, new Desert());
				    }

				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("Eau")) {
				       labyrinthe.getAventurier().setY(posY - 1);
				       labyrinthe.getCase(posX, posY - 1).action(aventurier);
				       JOptionPane.showMessageDialog(this, "Vous avez acquis une bouteille d'eau！");
				       labyrinthe.setCase(posX, posY - 1, new Desert());
				    }

				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("loup1")) {
					       labyrinthe.getAventurier().setY(posY - 1);
					       labyrinthe.getCase(posX, posY - 1).action(aventurier);
					       
					       JOptionPane.showMessageDialog(this, "Vous avez été mordu par un loup! \n VP-10");
					    }

				    
				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("Loup")) {
				       labyrinthe.getAventurier().setY(posY - 1);
				       labyrinthe.getCase(posX, posY - 1).action(aventurier);
				       labyrinthe.setCase(posX, posY - 1, new loup1());
				       JOptionPane.showMessageDialog(this, "Vous avez été mordu par un loup! \n VP-10");
				    }
				    
				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("serpent1")) {
					       labyrinthe.getAventurier().setY(posY - 1);
					       labyrinthe.getCase(posX, posY - 1).action(aventurier);
					      
					       if(aventurier.getDruide()==0) {
							     JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \n VP-10");
							  }else {
								  JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \nMais vous avez l'antidote.");
							  }
							
					    }
				    
				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("Serpent")) {
				       labyrinthe.getAventurier().setY(posY - 1);
				       labyrinthe.getCase(posX, posY - 1).action(aventurier);
				       labyrinthe.setCase(posX, posY - 1, new serpent1());
				       if(aventurier.getDruide()==0) {
						     JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \n VP-10");
						  }else {
							  JOptionPane.showMessageDialog(this, "Vous avez été mordu par un serpent venimeux! \nMais vous avez l'antidote.");
						  }
						
				    }
				    
				    

				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("Soigneur")) {
				       labyrinthe.getAventurier().setY(posY - 1);
				       labyrinthe.getCase(posX, posY - 1).action(aventurier);
				       JOptionPane.showMessageDialog(this, "Vous avez été traité par un Soigneur！" + "\n(VP + 20)");
				       labyrinthe.setCase(posX, posY - 1, new Desert());
				    }

				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("Druide")) {
				       labyrinthe.getAventurier().setY(posY - 1);
				       labyrinthe.getCase(posX, posY - 1).action(aventurier);
				       JOptionPane.showMessageDialog(this, "Le druide vous a donné une fiole d'antidote.");
				       labyrinthe.setCase(posX, posY - 1, new Desert());
				    }
				    
				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("voleur1")) {
					     labyrinthe.getAventurier().setX(posY - 1);
					     labyrinthe.getCase(posX, posY - 1).action(aventurier);
					     
					     if(aventurier.getBateau()==1) {
					     JOptionPane.showMessageDialog(this, "Vous êtes attaqué par des pirates et votre bateau coule.");
					     
					  }

					  
					  }

				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("Voleur")) {
					     labyrinthe.getAventurier().setX(posY - 1);
					     labyrinthe.getCase(posX, posY - 1).action(aventurier);
					     
					     if(aventurier.getBateau()==1) {
					     JOptionPane.showMessageDialog(this, "Vous êtes attaqué par des pirates et votre bateau coule.");
					     labyrinthe.setCase(posX, posY - 1, new voleur1());
					  }

					  
					  }
				    
				    
				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("Mage")) {
				       labyrinthe.getAventurier().setY(16);
				       labyrinthe.getAventurier().setX(11);
				       labyrinthe.getCase(11,16).action(aventurier);
				       JOptionPane.showMessageDialog(this, "Vous êtes transporté dans un autre lieu par le mage.");
				    }

				    if (labyrinthe.getCase(posX, posY - 1).getClassName().equals("Porte")) {
				       if (labyrinthe.getCase(15, 16).getClassName().equals("Desert")) {
				          labyrinthe.getAventurier().setY(posY - 1);
				          labyrinthe.getCase(posX, posY - 1).action(aventurier);
				          JOptionPane.showMessageDialog(this, "Vous avez ouvert une porte!");
				          labyrinthe.setCase(posX, posY - 1, new Desert());
				       } else {
				          JOptionPane.showMessageDialog(this, "Vous n'avez pas de clé pour ouvrir la porte！");
				       }
				    }

				  }




			/*----- On déclenche l'action de la case sur laquelle est l'aventurier -----*/
		

			/*----- On refait le dessin -----*/
			repaint();
			
			if (aventurier.getVp()<=0) {
				JOptionPane.showMessageDialog(this, " Vous êtes mort !"
						+"\n Vous avez fait : " + aventurier.getStep() + " coups !"
						+"\n Bonne chance la prochaine fois !");
									System.exit(0);
			}
		

			
			
			}

		} /*----- Fin de la classe interne Dessin -----*/

		
		}
/*----- Fin de la classe Vue -----*/